package daikon.dcomp;

public interface DCompMarker {}

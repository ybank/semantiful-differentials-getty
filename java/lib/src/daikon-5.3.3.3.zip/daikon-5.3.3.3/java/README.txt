Either this directory, or file daikon.jar, should be placed on your Java
classpath.

Each one contains the implementation of the Daikon invariant detector
and also supporting runtime files for the Daikon front end for Java.

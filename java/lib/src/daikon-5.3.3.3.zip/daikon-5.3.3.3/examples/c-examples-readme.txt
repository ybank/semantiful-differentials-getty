This directory contains several example C programs, to illustrate the use
of Daikon and the C front end.  For instructions on detecting invariants in
the example programs, see section "C examples" in the Daikon manual.

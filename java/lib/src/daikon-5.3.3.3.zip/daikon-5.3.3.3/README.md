[![Build Status](https://travis-ci.org/rarworld/daikon.svg?branch=FeatureExceptionHandling)](https://travis-ci.org/rarworld/daikon)

This is the distribution of a fork of the Daikon invariant detector,  
based on Daikon version 5.3.3, released May 2, 2016, and Daikon version 5.3.3.1_rar, released May 24, 2016

It is used internally by UCSD researchers. Please do not distribute.

If you are working with a Daikon distribution downloaded from the Daikon   
website, then most everything is setup and ready to go.  See the 'doc'  
subdirectory for additional information, including installation instructions.  
You should start out with the file:  
  doc/index.html  
The documentation also appears on the Daikon homepage:  
    http://plse.cs.washington.edu/daikon/  

If you are working with source cloned from the source code repository  
https://github.com/codespecs/daikon, then please review the file  
README.source.
